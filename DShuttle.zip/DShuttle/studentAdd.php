<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="contanier"> 
<div class="card card-register mx-auto mt-5">
<div class="card-header"><h2 style="text-shadow: 0px 1px 5px white;">Add new Record</h2> </div>
<div class="card-body" style="background-color: #009999;">
                 

                        <form role="form" method="post" action="student_trans.php?action=add">
                            
                            <div class="form-group">
                          
                            <input class="form-control" placeholder="First Name" name="First_Name">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Last Name" name="Last_Name">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Contact Number" name="Contact_NO">
                            </div> 
                           
                            
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="Grade" name="Grade">
                            </div> 
                            <?php
                                $queryy = "SELECT * FROM `status`";
                                $res1 = mysqli_query($db,$queryy) or die ("Error: $queryy");

                                $status ="<select class='form-control' name='status' required>
                                            <option value='' disabled selected hidden>Select Status</option>";
                                while($row = mysqli_fetch_assoc($res1)){
                                $status .="<option value='".$row['Status_ID']."'>".$row['status_name']."</option>";
                                }
                                $status .="</select>";
                          ?>
                           <div class="form-group">
                              <?php echo $status; ?>
                            </div>
                            <?php
                                $queryyy = "SELECT * FROM `school`";
                                $res2 = mysqli_query($db,$queryyy) or die ("Error: $queryyy");

                                $school ="<select class='form-control' name='school' required>
                                            <option value='' disabled selected hidden>Select School</option>";
                                while($row = mysqli_fetch_assoc($res2)){
                                $school .="<option value='".$row['School_ID']."'>".$row['School_Name']."</option>";
                                }
                                $school .="</select>";
                          ?>
                           <div class="form-group">
                              <?php echo $school; ?>
                            </div>
                            <?php
                                $queryyyy = "SELECT * FROM `vehicle`";
                                $res3= mysqli_query($db,$queryyyy) or die ("Error: $queryyyy");

                                $vehicle ="<select class='form-control' name='vehicle' required>
                                            <option value='' disabled selected hidden>Select Vehicle</option>";
                                while($row = mysqli_fetch_assoc($res3)){
                                $vehicle .="<option value='".$row['Vehicle_ID']."'>".$row['Reg_NO']."</option>";
                                }
                                $vehicle .="</select>";
                          ?>
                           <div class="form-group">
                              <?php echo $vehicle; ?>
                            </div>
                           
                            <button type="submit" class="btn btn-default"> <h6> Save Record </h6> </button>
                            <button type="reset" class="btn btn-default"> <h6> Clear </h6> </button>


                      </form>  
                    </div>
                </div>

        </div>
        <!-- /.container-fluid -->
 <?php include 'footer.php'; ?>