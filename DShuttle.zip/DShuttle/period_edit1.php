<?php
include('connection.php');
include('topnav.php');
?>

<body>
<?php
$zz = $_POST['Period_ID']; 
$sid = $_POST['Student_ID'];
$i = $_POST['Start_Date'];
$a = $_POST['End_Date'];


$query = 'UPDATE period set Student_ID ="'.$sid.'", Start_Date ="'.$i.'", End_Date ="'.$a.'" WHERE
Period_ID ="'.$zz.'"';
$result = mysqli_query($db, $query) or die(mysqli_error($db));							
?>
<script type="text/javascript">
alert("Successfully Updated!");
window.location = "period.php";
</script>
 </body>