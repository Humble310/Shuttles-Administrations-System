<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="col-lg-12">
    <div>
        <i class="fas fa-table"></i>
        Period Records <br><br>
        <a class="btn btn-xs btn-primary" href="period_add.php?action=add"><i class="fa fa-user-plus"></i> Add New</a>
    </div>
    <br></br>
    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Period ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Option</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = 'SELECT a.`Period_ID`, b.`First_Name`, b.`Last_Name`, a.`Start_Date`, a.`End_Date`
                          FROM `period` a, `student` b
                          WHERE a.`Student_ID` = b.`Student_ID`';

                $result = mysqli_query($db, $query) or die(mysqli_error($db));

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td>' . $row['Period_ID'] . '</td>';
                    echo '<td>' . $row['First_Name'] . '</td>';
                    echo '<td>' . $row['Last_Name'] . '</td>';
                    echo '<td>' . $row['Start_Date'] . '</td>';
                    echo '<td>' . $row['End_Date'] . '</td>';
                    echo '<td>';
                    echo '<a type="button" class="btn btn-xs btn-warning fa fa-edit" href="period_edit.php?action=edit&id=' . $row['Period_ID'] . '"></a>';
                    echo '<a type="button" class="btn btn-xs btn-danger fa fa-trash" href="period_del.php?type=period&delete&id=' . $row['Period_ID'] . '"></a>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'footer.php'; ?>
