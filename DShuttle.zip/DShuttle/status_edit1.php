<?php
include 'connection.php';
include 'topnav.php';

if (isset($_POST['id']) && isset($_POST['status_name'])) {
    $zz = $_POST['id'];
    $name = $_POST['status_name'];

    // Use prepared statement to prevent SQL injection
    $query = 'UPDATE status SET status_name = ? WHERE Status_ID = ?';
    $stmt = mysqli_prepare($db, $query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, 'si', $name, $zz);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo '<script type="text/javascript">';
        echo 'alert("Update Successful.");';
        echo 'window.location = "status.php";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Update Failed. Please try again.");';
        echo 'window.location = "status.php";';
        echo '</script>';
    }

    // Close the prepared statement
    mysqli_stmt_close($stmt);
} else {
    // Redirect to an error page or handle the error as needed
    echo '<script type="text/javascript">';
    echo 'alert("Invalid data. Please try again.");';
    echo 'window.location = "error.php";'; // Replace "error.php" with your actual error page
    echo '</script>';
}

include 'footer.php';
?>
