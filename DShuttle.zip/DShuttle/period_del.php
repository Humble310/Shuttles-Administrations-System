<?php
include('connection.php');
include('topnav.php');
?>

<body>
    <?php
    if (!isset($_GET['do']) || $_GET['do'] != 1) {
        switch ($_GET['type']) {
            case 'period':
                // Validate and sanitize input
                $driver_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

                if ($driver_id > 0) {
                    $query = 'DELETE FROM period WHERE Period_ID = ' . $period_id;
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                ?>
                    <script type="text/javascript">
                        if (confirm("Are you sure you want to delete this record?")) {
                            alert("Successfully Deleted.");
                            window.location = "period.php";
                        } else {
                            window.location = "period.php"; // Redirect to the list page if the user cancels
                        }
                    </script>
    <?php
                } else {
                    // Handle invalid or missing ID
                    echo "Invalid or missing ID";
                }
                break;
        }
    }
    ?>
</body>

<?php include 'footer.php'; ?>
