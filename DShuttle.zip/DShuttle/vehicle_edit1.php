<?php
include 'connection.php';
include 'topnav.php';

$zz = $_POST['id'];
$reg = $_POST['Reg_NO'];
$des = $_POST['Description'];

$query = 'UPDATE vehicle SET 
              Reg_NO = "'.$reg.'",
              Description = "'.$des.'"
           WHERE Vehicle_ID = "'.$zz.'"';

$result = mysqli_query($db, $query) or die(mysqli_error($db));
?>

<script type="text/javascript">
    alert("Update Successful.");
    window.location = "vehicle.php";
</script>

<?php include 'footer.php'; ?>
