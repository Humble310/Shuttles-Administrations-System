<?php include 'connection.php';
include 'topnav.php'; ?>

         <div class="col-lg-12">
                       <div>
            <i class="fas fa-table"></i>

            School Records <br></br>  
             <a></a>  
             <a class="btn btn-xs btn-primary" href="school_add.php?action=add"><i class="fa fa-user-plus"></i> Add New</a>
            </div> 

                        <br> </br>       
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>School ID</th>
                                        <th>School Name</th>
                                        <th>Address</th>
                                        <th>Option</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php                  
                $query = 'SELECT * FROM school';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['School_ID'].'</td>';
                            echo '<td>'. $row['School_Name'].'</td>';
                            echo '<td>'. $row['Location'].'</td>';
                            
                            echo '<td>';
                            echo ' <a  type="button" class="btn btn-xs btn-warning fa fa-edit" href="school_edit.php?action=edit & id='.$row['School_ID'] . '"> </a> ';
                            echo ' <a  type="button" class="btn btn-xs btn-danger fa fa-trash" href="school_del.php?type=school&delete & id='.$row['School_ID'] . '"> </a> </td>';
                            echo '</tr> ';
                }
            ?> 
                                    
                                </tbody>
                            </table>
                        </div><?php include 'footer.php'; ?>