<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="contanier">
<div class="card card-register mx-auto mt-5" >
<?php 
$query = 'SELECT * FROM driver
              WHERE
              Driver_ID ="'.$_GET['id'].'"';
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $zz= $row['Driver_ID'];
                $i= $row['First_Name'];
                $f= $row['Last_Name'];
                $g= $row['Address'];
                $h= $row['Contact_NO'];
               
             
              }
              
              $id = $_GET['id'];
         
?>

             <div class="card-header">
                  <h2 style="text-shadow: 0px 1px 5px white;">Edit Records</h2>
                      <div div class="card-body" style="background-color: #009999;">

                        <form role="form" method="post" action="driver_edit1.php">
                            
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $zz; ?>" />
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="First Name" name="First_Name" value="<?php echo $i; ?>">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Last Name" name="Last_Name" value="<?php echo $f; ?>">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Address" name="Address" value="<?php echo $g; ?>">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Contact Number" name="Contact_NO" value="<?php echo $h; ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-default">Update Record</button>
                         


                      </form>  
                    </div>
                </div>
                
            </div>
            <!-- /.container-fluid -->

        </div>
        <?php include 'footer.php'; ?>