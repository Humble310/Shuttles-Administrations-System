<?php
include('connection.php');
include('topnav.php');
?>

<body>
    <?php
    if (!isset($_GET['do']) || $_GET['do'] != 1) {
        switch ($_GET['type']) {
            case 'vehicle':
                // Validate and sanitize input
                $vehicle_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

                if ($vehicle_id > 0) {
                    $query = 'DELETE FROM vehicle WHERE Vehicle_ID = ' . $vehicle_id;
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                ?>
                    <script type="text/javascript">
                        if (confirm("Are you sure you want to delete this record?")) {
                            alert("Successfully Deleted.");
                            window.location = "vehicle.php";
                        } else {
                            window.location = "vehicle.php"; // Redirect to the list page if the user cancels
                        }
                    </script>
    <?php
                } else {
                    // Handle invalid or missing ID
                    echo "Invalid or missing ID";
                }
                break;
        }
    }
    ?>
</body>

<?php include 'footer.php'; ?>
