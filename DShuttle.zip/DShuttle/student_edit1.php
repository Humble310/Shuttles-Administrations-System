<?php
include 'connection.php';
include 'topnav.php';

$zz = $_POST['id'];
$fn = $_POST['First_Name'];
$ln = $_POST['Last_Name'];
$cn = $_POST['Contact_NO'];
$grd = $_POST['Grade'];
$sid = $_POST['Status_ID'];
$vid = $_POST['Vehicle_ID'];
$scid = $_POST['School_ID'];

$query = 'UPDATE student SET
            First_Name = ?,
            Last_Name = ?,
            Contact_NO = ?,
            Grade = ?,
            Status_ID = ?,
            Vehicle_ID = ?,
            School_ID = ?
          WHERE Student_ID = ?';

$stmt = mysqli_prepare($db, $query);

mysqli_stmt_bind_param($stmt, "ssssssss", $fn, $ln, $cn, $grd, $sid, $vid, $scid, $zz);

$result = mysqli_stmt_execute($stmt);

mysqli_stmt_close($stmt);
?>

<script type="text/javascript">
    alert("Update Successful.");
    window.location = "student.php";
</script>

<?php include 'footer.php'; ?>
