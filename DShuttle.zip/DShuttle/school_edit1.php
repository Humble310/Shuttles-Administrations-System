<?php include 'connection.php';
include 'topnav.php'; ?>
<body>
<?php
			$zz = $_POST['id'];
			$name = $_POST['School_Name'];
			$desc = $_POST['Location'];
			 	
			
		
			$query = 'UPDATE school set School_Name ="'.$name.'", 
            Location="'.$desc.'" WHERE
					School_ID ="'.$zz.'"';
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "school.php";
		</script>
 <?php include 'footer.php'; ?>