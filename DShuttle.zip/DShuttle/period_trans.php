<?php include'topnav.php' ;?>
<?php include'connection.php' ;?>

 <div class="col-lg-12">
                <?php
						$fname = $_POST['First_Name'];
						$lname = $_POST['Last_Name'];
					    $sd= $_POST['Start_Date'];
					    $ed= $_POST['End_Date'];

						
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO period
								(Period_ID,Student_ID,Start_Date,End_Date)
								VALUES ('Null', ".$fname.",".$lname.",'".$sd."', '".$ed."')";
								mysqli_query($db,$query)or die (mysqli_error($db));
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "period.php";
		</script>
                    </div>