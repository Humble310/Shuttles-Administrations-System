<?php include'topnav.php' ;?>
<?php include'connection.php' ;?>

 <div class="col-lg-12">
                <?php
            
						$reg= $_POST['Reg_NO'];
						$des= $_POST['Description'];
                       
						
						
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO vehicle
								(Vehicle_ID, Reg_NO,Description)
								VALUES ('NULL','".$reg."','".$des."')";
								 mysqli_query($db, $query) or die(mysqli_error($db));
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "vehicle.php";
		</script>
                    </div>