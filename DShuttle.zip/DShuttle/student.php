<?php
include 'connection.php';
include 'topnav.php';
?>

<div class="col-lg-12">
    <div>
        <i class="fas fa-table"></i>
        Student Records <br><br>
        <a class="btn btn-xs btn-primary" href="studentAdd.php?action=add"><i class="fa fa-user-plus"></i> Add New</a>
    </div>

    <br><br>

    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact No.</th>
                    <th>Grade</th>
                    <th>Status</th>
                    <th>Vehicle</th>
                    <th>School</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = 'SELECT a.`Student_ID`, a.`First_Name`, a.`Last_Name`, a.`Grade`, a.`Contact_NO`, b.`status_name`, c.`Reg_NO`, d.`School_Name` FROM `student` a, `status` b, `vehicle` c, `school` d WHERE a.`Status_ID` = b.`Status_ID` AND a.`vehicle_ID` = c.`Vehicle_ID` AND a.`School_ID` = d.`School_ID`';
                $result = mysqli_query($db, $query) or die(mysqli_error($db));

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td>' . $row['Student_ID'] . '</td>';
                    echo '<td>' . $row['First_Name'] . '</td>';
                    echo '<td>' . $row['Last_Name'] . '</td>';
                    echo '<td>' . $row['Contact_NO'] . '</td>';
                    echo '<td>' . $row['Grade'] . '</td>';
                    echo '<td>' . $row['status_name'] . '</td>';
                    echo '<td>' . $row['Reg_NO'] . '</td>';
                    echo '<td>' . $row['School_Name'] . '</td>';
                    echo '<td>';
                    echo '<a class="btn btn-xs btn-warning" href="student_edit.php?action=edit&id=' . $row['Student_ID'] . '"><i class="fa fa-edit"></i></a> ';
                   echo '<a class="btn btn-xs btn-danger" href="studentdel.php?type=student&delete&id=' . $row['Student_ID'] . '"><i class="fa fa-trash"></i></a>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
