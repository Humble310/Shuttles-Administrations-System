<?php
include('connection.php');
include('topnav.php');
?>

<body>
    <?php
    if (!isset($_GET['do']) || $_GET['do'] != 1) {
        switch ($_GET['type']) {
            case 'school':
                // Validate and sanitize input
                $school_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

                if ($school_id > 0) {
                    $query = 'DELETE FROM school WHERE School_ID = ' . $school_id;
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                ?>
                    <script type="text/javascript">
                        if (confirm("Are you sure you want to delete this record?")) {
                            alert("Successfully Deleted.");
                            window.location = "school.php";
                        } else {
                            window.location = "school.php"; // Redirect to the list page if the user cancels
                        }
                    </script>
    <?php
                } else {
                    // Handle invalid or missing ID
                    echo "Invalid or missing ID";
                }
                break;
        }
    }
    ?>
</body>

<?php include 'footer.php'; ?>
