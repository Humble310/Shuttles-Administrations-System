<?php
// Before we store information of our member, we need to start first the session
session_start(); 

// Create a new function to check if the session variable MEMBER_ID is set
function logged_in() {
    return isset($_SESSION['MEMBER_ID']);
}

// This function checks if the session member is not set, then it will be redirected to login.php
function confirm_logged_in() {
    if (!logged_in()) {
        header("Location: login.php");
        exit(); // Ensure that script stops execution after redirection
    }
}
?>
