<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="contanier"> 
<div class="card card-register mx-auto mt-5">
<div class="card-header"><h2 style="text-shadow: 0px 1px 5px white;">Add new Record</h2> </div>
<div class="card-body" style="background-color: #009999;">
                 

                        <form role="form" method="post" action="period_trans.php?action=add">

                            <?php
                                $queryy = "SELECT * FROM `student`";
                                $res1 = mysqli_query($db,$queryy) or die ("Error: $queryy");

                                $fn ="<select class='form-control' name='First_Name' required>
                                            <option value='' disabled selected hidden>Select First Name</option>";
                                while($row = mysqli_fetch_assoc($res1)){
                                $fn .="<option value='".$row['Student_ID']."'>".$row['First_Name']."</option>";
                                }
                                $fn .="</select>";
                          ?>
                           <div class="form-group">
                              <?php echo $fn; ?>
                            </div>  
                            <?php
                                $queryyy = "SELECT * FROM `student`";
                                $res2 = mysqli_query($db,$queryyy) or die ("Error: $queryyy");

                                $ln ="<select class='form-control' name='Last_Name' required>
                                            <option value='' disabled selected hidden>Select Last Name</option>";
                                while($row = mysqli_fetch_assoc($res2)){
                                $ln .="<option value='".$row['Student_ID']."'>".$row['Last_Name']."</option>";
                                }
                                $ln .="</select>";
                          ?>
                           <div class="form-group">
                              <?php echo $ln; ?>
                            </div>   
                            <div class="form-group">
                                <p> Start Date </p>
                            <input class="form-control" type="date" name="Start_Date">
                            </div>
                            <div class="form-group">
                                <p> End Date </p>
                            <input class="form-control" type="date" name="End_Date">
                            </div>
                            <button type="submit" class="btn btn-default"> <h6> Save Record </h6> </button>
                            <button type="reset" class="btn btn-default"> <h6> Clear </h6> </button>


                      </form>  
                    </div>
                </div>

        </div>
        <!-- /.container-fluid -->
 <?php include 'footer.php'; ?>