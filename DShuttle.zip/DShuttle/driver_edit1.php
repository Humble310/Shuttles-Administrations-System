<?php include 'connection.php';
include 'topnav.php'; ?>
<body>
<?php
			$zz = $_POST['id'];
			$fname = $_POST['First_Name'];
            $lname = $_POST['Last_Name'];
            $addr = $_POST['Address'];
            $cn = $_POST['Contact_NO'];

			
			 	
			
		
			$query = 'UPDATE driver SET 
              First_Name = "'.$fname.'",
              Last_Name = "'.$lname.'",
              Address = "'.$addr.'",
              Contact_NO = "'.$cn.'"
           WHERE Driver_ID = "'.$zz.'"';

           $result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "driver.php";
		</script>
 <?php include 'footer.php'; ?>