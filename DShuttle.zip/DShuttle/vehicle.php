<?php
include 'connection.php';
include 'topnav.php';
?>

<div class="col-lg-12">
    <div>
        <i class="fas fa-table"></i>
        Vehicle Records <br><br>
        <a class="btn btn-xs btn-primary" href="vehicle_add.php?action=add"><i class="fa fa-user-plus"></i> Add New</a>
    </div>

    <br><br>

    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Driver ID</th>
                    <th>Reg_NO</th>
                    <th>Description</th>
                    
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = 'SELECT * FROM vehicle';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>';
                    echo '<td>' . $row['Vehicle_ID'] . '</td>';
                    echo '<td>' . $row['Reg_NO'] . '</td>';
                    echo '<td>' . $row['Description'] . '</td>';
          
                    echo '<td>';
                    echo '<a class="btn btn-xs btn-warning" href="vehicle_edit.php?action=edit&id=' . $row['Vehicle_ID'] . '"><i class="fa fa-edit"></i></a> ';
                    echo '<a class="btn btn-xs btn-danger" href="vehicle_del.php?type=vehicle&delete&id=' . $row['Vehicle_ID'] . '"><i class="fa fa-trash"></i></a>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
a