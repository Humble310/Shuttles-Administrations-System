<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="contanier">
<div class="card card-register mx-auto mt-5" >
<?php 
$query = 'SELECT * FROM vehicle
              WHERE
              Vehicle_ID ="'.$_GET['id'].'"';
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $zz= $row['Vehicle_ID'];
                $reg= $row['Reg_NO'];
                $des= $row['Description'];
              
               
             
              }
              
              $zz = $_GET['id'];
         
?>

             <div class="card-header">
                  <h2 style="text-shadow: 0px 1px 5px white;">Edit Records</h2>
                      <div div class="card-body" style="background-color: #009999;">

                        <form role="form" method="post" action="vehicle_edit1.php">
                            
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $zz; ?>" />
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Car Registration" name="Reg_NO" value="<?php echo $reg; ?>">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Description" name="Description" value="<?php echo $des; ?>">
                            </div>
                            
                            
                            <button type="submit" class="btn btn-default">Update Record</button>
                         


                      </form>  
                    </div>
                </div>
                
            </div>
            <!-- /.container-fluid -->

        </div>
        <?php include 'footer.php'; ?>