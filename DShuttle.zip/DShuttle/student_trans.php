<?php include 'index.php'; ?>
<?php include 'connection.php'; ?>

<div class="col-lg-12">
    <?php
    $fname = $_POST['First_Name'];
    $lname = $_POST['Last_Name'];
    $cn = $_POST['Contact_NO'];
    $grade = $_POST['Grade'];
    $stat = $_POST['status'];
    $reg = $_POST['vehicle'];
    $schoo = $_POST['school'];

    switch ($_GET['action']) {
        case 'add':
            $query = "INSERT INTO student
                        (Student_ID, First_Name, Last_Name, Contact_NO, Grade, Status_ID, Vehicle_ID, School_ID)
                        VALUES (NULL, '".$fname."', '".$lname."', '".$cn."', '".$grade."', ".$stat.", ".$reg.", ".$schoo.")";
            mysqli_query($db, $query) or die(mysqli_error($db));
            break;
    }
    ?>
    <script type="text/javascript">
        alert("Successfully added.");
        window.location = "student.php";
    </script>
</div>
