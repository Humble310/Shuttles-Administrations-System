<?php include'topnav.php' ;?>
<?php include'connection.php' ;?>

 <div class="col-lg-12">
                <?php
            
						$fname= $_POST['First_Name'];
						$lname= $_POST['Last_Name'];
                        $addr= $_POST['Address'];
						$cn= $_POST['Contact_NO'];
						
						
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO driver
								(Driver_ID, First_Name,Last_Name,Address, Contact_NO)
								VALUES ('NULL','".$fname."','".$lname."','".$addr."','".$cn."')";
								 mysqli_query($db, $query) or die(mysqli_error($db));
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "driver.php";
		</script>
                    </div>