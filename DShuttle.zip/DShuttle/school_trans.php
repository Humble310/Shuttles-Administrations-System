<?php include'topnav.php' ;?>
<?php include'connection.php' ;?>

 <div class="col-lg-12">
                <?php
            
						$name= $_POST['School_Name'];
						$addr= $_POST['Location'];
						
						
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO school
								(School_ID, School_Name,Location)
								VALUES ('NULL','".$name."','".$addr."')";
								mysqli_query($db,$query)or die(mysqli_error($db));
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "school.php";
		</script>
                    </div>