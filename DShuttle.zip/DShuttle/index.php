<?php
include 'connection.php';
include 'topnav.php';
?>

          <!-- Breadcrumbs-->
           
          </ol>
           <div class="Student_logo">
            <a href="#" class="image full"><img src="image/student_grp_1.jpg" style="width:1268px;" style="background-attachment: fixed;" style="background-size: contain;"  > </a>
          <!-- Page Content -->
          <h4></h4>
          <hr> 
          <p> <h5>  </h5></p>
<?php include 'footer.php'; ?>