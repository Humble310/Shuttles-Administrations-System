<?php include 'connection.php';
include 'topnav.php'; ?>

<div class="contanier">
<div class="card card-register mx-auto mt-5">
<?php 
$query = 'SELECT * FROM student
              WHERE
              Student_ID ='.$_GET['id'];
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $zz= $row['Student_ID'];
                $i= $row['First_Name'];
                $a=$row['Last_Name'];
                $b=$row['Contact_NO'];
                $c=$row['Grade'];
                $d=$row['Status_ID'];
                $e=$row['Vehicle_ID'];
                $f=$row['School_ID'];
              }

              
              $id = $_GET['id'];
         
?>

<div class="card-header">
                  <h1 style="text-shadow: 0px 1px 5px white;">Edit Records</h1>
                    <div div class="card-body" style="background-color: #009999;">

                        <form role="form" method="post" action="student_edit1.php">
                            
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $zz; ?>" />
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="First Name" name="First_Name" value="<?php echo $i; ?>">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Last Name" name="Last_Name" value="<?php echo $a; ?>">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Contact Number" name="Contact_NO" value="<?php echo $b; ?>">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Grade" name="Grade" value="<?php echo $c; ?>">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Status ID" name="Status_ID" value="<?php echo $d; ?>">
                            </div> 
                             <div class="form-group">
                              <input class="form-control" placeholder="Vehicle ID" name="Vehicle_ID" value="<?php echo $e; ?>">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="School ID" name="School_ID" value="<?php echo $f; ?>">
                            </div> 
                            <button type="submit" class="btn btn-default">Update Record</button>
