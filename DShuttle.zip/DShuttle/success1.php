<?php
$servername = "fdb1033.awardspace.net";
$username = "4426757_dsshuttle";
$Password = "Humble281219!";
$dbname = "4426757_dsshuttle";

$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$user = $_POST['user'];
$password = $_POST['password']; // Adjusted variable name
$confirm = $_POST['confirmpassword']; // Adjusted variable name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $Password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $SQL = "INSERT INTO admin (fname, lname, user, password, confirmpassword, Position) VALUES (?, ?, ?, MD5(?), MD5(?), 'ADMIN')";
    $stmt = $conn->prepare($SQL);
    $stmt->execute([$firstname, $lastname, $user, $password, $confirm]);

    // Redirect to login page after successful registration
    header("Location: login.php");
    exit();
} catch (PDOException $e) {
    // Handle exceptions appropriately, e.g., log the error
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
