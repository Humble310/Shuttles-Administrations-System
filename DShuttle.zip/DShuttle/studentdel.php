<?php
include('connection.php');
include('topnav.php');
?>

<body>
    <?php
    if (!isset($_GET['do']) || $_GET['do'] != 1) {
        switch ($_GET['type']) {
            case 'student':
                // Validate and sanitize input
                $student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

                if ($student_id > 0) {
                    $query = 'DELETE FROM student WHERE Student_ID = ' . $student_id;
                    $result = mysqli_query($db, $query);

                    if ($result) {
    ?>
                        <script type="text/javascript">
                            if (confirm("Are you sure you want to delete this record?")) {
                                alert("Successfully Deleted.");
                                window.location = "student.php";
                            } else {
                                window.location = "student.php"; // Redirect to the list page if the user cancels
                            }
                        </script>
    <?php
                    } else {
                        echo "Error: " . mysqli_error($db);
                    }
                } else {
                    // Handle invalid or missing ID
                    echo "Invalid or missing ID";
                }
                break;
        }
    }
    ?>
</body>
</html>
