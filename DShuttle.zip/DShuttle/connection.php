<?php
 $db = mysqli_connect('fdb1033.awardspace.net', '4426757_dsshuttle', 'Humble281219!') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, '4426757_dsshuttle' ) or die(mysqli_error($db));
?>